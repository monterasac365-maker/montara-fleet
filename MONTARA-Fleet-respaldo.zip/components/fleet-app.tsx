'use client';
import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  Building2,
  CarFront,
  ChevronRight,
  CircleDollarSign,
  ClipboardList,
  Download,
  FileText,
  Gauge,
  LayoutDashboard,
  LogOut,
  Menu,
  Plus,
  Search,
  Send,
  Settings,
  ShieldCheck,
  UploadCloud,
  Users,
  Wrench,
  X,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import CorporateAccess from '@/components/corporate-access';

type Row = {
  id: string;
  title: string;
  subtitle: string;
  meta: string;
  status: string;
  amount?: string;
};
const modules: Record<
  string,
  { title: string; description: string; rows: Row[] }
> = {
  Flota: {
    title: 'Flota',
    description: 'Unidades y equipos registrados',
    rows: [
      {
        id: 'MNT-001',
        title: 'Toyota Hilux 4x4',
        subtitle: 'ABC-123 · Camioneta',
        meta: '80,250 km · Mina Norte',
        status: 'Alquilada',
        amount: 'S/ 6,000 / mes',
      },
      {
        id: 'MNT-002',
        title: 'Toyota Hilux 4x4',
        subtitle: 'DEF-456 · Camioneta',
        meta: '42,100 km · Base Lima',
        status: 'Disponible',
        amount: 'S/ 6,000 / mes',
      },
      {
        id: 'MNT-003',
        title: 'Volvo FMX 440',
        subtitle: 'GHI-789 · Volquete',
        meta: '3,410 h · Taller central',
        status: 'Mantenimiento',
        amount: 'S/ 14,500 / mes',
      },
    ],
  },
  Propietarios: {
    title: 'Propietarios',
    description: 'Titulares y unidades asociadas',
    rows: [
      {
        id: 'PRO-001',
        title: 'MONTARA S.A.C.',
        subtitle: 'Empresa · RUC ficticio',
        meta: '2 unidades asociadas',
        status: 'Activo',
      },
      {
        id: 'PRO-002',
        title: 'Propietario demostración',
        subtitle: 'Persona natural · Documento ficticio',
        meta: '1 unidad asociada',
        status: 'Activo',
      },
    ],
  },
  Clientes: {
    title: 'Clientes',
    description: 'Empresas, contactos y proyectos',
    rows: [
      {
        id: 'CLI-001',
        title: 'Compañía Minera Demo S.A.C.',
        subtitle: 'Minería · Proyecto Cobre Norte',
        meta: '2 alquileres activos',
        status: 'Activo',
        amount: 'Deuda S/ 3,600',
      },
      {
        id: 'CLI-002',
        title: 'Constructora Horizonte Demo',
        subtitle: 'Construcción · Proyecto Vial Sur',
        meta: 'Sin deuda pendiente',
        status: 'Activo',
      },
    ],
  },
  Alquileres: {
    title: 'Alquileres',
    description: 'Cotizaciones, reservas y operaciones activas',
    rows: [
      {
        id: 'ALQ-026',
        title: 'Compañía Minera Demo S.A.C.',
        subtitle: 'MNT-001 · Toyota Hilux',
        meta: '01 ago — 31 dic 2026',
        status: 'Activo',
        amount: 'S/ 6,000 / mes',
      },
      {
        id: 'ALQ-027',
        title: 'Constructora Horizonte Demo',
        subtitle: 'MNT-002 · Toyota Hilux',
        meta: '15 sep — 15 dic 2026',
        status: 'Reservado',
        amount: 'S/ 5,800 / mes',
      },
    ],
  },
  Contratos: {
    title: 'Contratos',
    description: 'Vigencia, montos y documentación',
    rows: [
      {
        id: 'CTR-2026-018',
        title: 'Compañía Minera Demo S.A.C.',
        subtitle: '1 unidad · MNT-001',
        meta: 'Vence 31 dic 2026',
        status: 'Vigente',
        amount: 'S/ 30,000',
      },
      {
        id: 'CTR-2026-012',
        title: 'Constructora Horizonte Demo',
        subtitle: '1 unidad · MNT-002',
        meta: 'Vence en 12 días',
        status: 'Por vencer',
        amount: 'S/ 17,400',
      },
    ],
  },
  Pagos: {
    title: 'Pagos y facturación',
    description: 'Comprobantes y cuentas por cobrar',
    rows: [
      {
        id: 'F001-0082',
        title: 'Compañía Minera Demo S.A.C.',
        subtitle: 'Periodo agosto 2026',
        meta: 'Venció 25 ago 2026',
        status: 'Vencido',
        amount: 'S/ 3,600',
      },
      {
        id: 'F001-0083',
        title: 'Constructora Horizonte Demo',
        subtitle: 'Periodo agosto 2026',
        meta: 'Vence 10 sep 2026',
        status: 'Pendiente',
        amount: 'S/ 6,844',
      },
    ],
  },
  Gastos: {
    title: 'Gastos',
    description: 'Costos operativos por unidad',
    rows: [
      {
        id: 'GAS-104',
        title: 'Cambio de aceite y filtros',
        subtitle: 'MNT-001 · Taller Demo',
        meta: '28 ago 2026 · Mantenimiento',
        status: 'Registrado',
        amount: 'S/ 680',
      },
      {
        id: 'GAS-103',
        title: 'Póliza vehicular',
        subtitle: 'MNT-002 · Aseguradora Demo',
        meta: '20 ago 2026 · Seguro',
        status: 'Registrado',
        amount: 'S/ 1,950',
      },
    ],
  },
  Mantenimiento: {
    title: 'Mantenimiento',
    description: 'Servicios preventivos, correctivos e inspecciones',
    rows: [
      {
        id: 'MAN-042',
        title: 'Mantenimiento preventivo 80,000 km',
        subtitle: 'MNT-001 · Toyota Hilux',
        meta: 'Próximo: 85,000 km',
        status: 'Completado',
        amount: 'S/ 680',
      },
      {
        id: 'MAN-043',
        title: 'Reparación sistema hidráulico',
        subtitle: 'MNT-003 · Volvo FMX',
        meta: 'En Taller central',
        status: 'En proceso',
        amount: 'S/ 2,450',
      },
    ],
  },
  Documentos: {
    title: 'Documentos',
    description: 'SOAT, seguros, revisiones y certificados',
    rows: [
      {
        id: 'DOC-029',
        title: 'SOAT',
        subtitle: 'MNT-001 · ABC-123',
        meta: 'Vence 08 sep 2026',
        status: 'Por vencer',
      },
      {
        id: 'DOC-030',
        title: 'Revisión técnica',
        subtitle: 'MNT-002 · DEF-456',
        meta: 'Vence 18 feb 2027',
        status: 'Vigente',
      },
    ],
  },
  Alertas: {
    title: 'Centro de alertas',
    description: 'Vencimientos y tareas que requieren atención',
    rows: [
      {
        id: 'ALT-01',
        title: 'SOAT próximo a vencer',
        subtitle: 'MNT-001 · ABC-123',
        meta: 'Quedan 8 días',
        status: 'Crítica',
      },
      {
        id: 'ALT-02',
        title: 'Contrato próximo a vencer',
        subtitle: 'CTR-2026-012',
        meta: 'Quedan 12 días',
        status: 'Advertencia',
      },
      {
        id: 'ALT-03',
        title: 'Pago pendiente',
        subtitle: 'F001-0082',
        meta: '6 días de retraso',
        status: 'Crítica',
      },
    ],
  },
  Reportes: {
    title: 'Reportes',
    description: 'Rentabilidad y desempeño operativo',
    rows: [
      {
        id: 'REP-01',
        title: 'Rentabilidad por unidad',
        subtitle: 'Ingresos, gastos y utilidad',
        meta: 'Agosto 2026',
        status: 'Disponible',
      },
      {
        id: 'REP-02',
        title: 'Ocupación de flota',
        subtitle: 'Uso por categoría y estado',
        meta: 'Agosto 2026',
        status: 'Disponible',
      },
    ],
  },
  Solicitudes: {
    title: 'Solicitudes de servicio',
    description: 'Pedidos enviados por clientes y prospectos',
    rows: [
      {
        id: 'SOL-001',
        title: 'Alquiler de camioneta 4x4',
        subtitle: 'Empresa prospecto demostración',
        meta: 'Proyecto minero · 3 meses',
        status: 'Pendiente',
      },
      {
        id: 'SOL-002',
        title: 'Cotización de volquete',
        subtitle: 'Cliente demostración',
        meta: 'Obra vial · 6 meses',
        status: 'En revisión',
      },
    ],
  },
  Configuración: {
    title: 'Configuración',
    description: 'Empresa, impuestos, categorías, usuarios y alertas',
    rows: [
      {
        id: 'CFG-01',
        title: 'MONTARA S.A.C.',
        subtitle: 'Empresa · PEN (S/)',
        meta: 'RUC y datos de contacto',
        status: 'Configurado',
      },
      {
        id: 'CFG-02',
        title: 'IGV',
        subtitle: 'Impuesto general a las ventas',
        meta: '18% configurable',
        status: 'Activo',
      },
      {
        id: 'CFG-03',
        title: 'Usuarios y roles',
        subtitle: '2 perfiles de acceso',
        meta: 'Administrador y Solicitante',
        status: 'Configurado',
      },
      {
        id: 'USR-ADM-01',
        title: 'Alyson Noely Diaz Mamani',
        subtitle: 'Administrador 1',
        meta: 'Acceso completo',
        status: 'Activo',
      },
      {
        id: 'USR-ADM-02',
        title: 'Maiquel Visa Diaz',
        subtitle: 'Administrador 2',
        meta: 'Acceso completo',
        status: 'Activo',
      },
    ],
  },
};
const nav = [
  ['Resumen', LayoutDashboard],
  ['Flota', CarFront],
  ['Propietarios', Building2],
  ['Clientes', Users],
  ['Solicitudes', ClipboardList],
  ['Alquileres', Gauge],
  ['Contratos', FileText],
  ['Pagos', CircleDollarSign],
  ['Gastos', CircleDollarSign],
  ['Mantenimiento', Wrench],
  ['Documentos', ShieldCheck],
  ['Alertas', Bell],
  ['Reportes', FileText],
  ['Configuración', Settings],
] as const;
const trend = [
  { m: 'Mar', v: 8400 },
  { m: 'Abr', v: 10900 },
  { m: 'May', v: 9200 },
  { m: 'Jun', v: 13200 },
  { m: 'Jul', v: 15100 },
  { m: 'Ago', v: 18400 },
];
const pill = (s: string) =>
  s.match(/Vencido|Crítica|Mantenimiento/)
    ? 'bg-red-50 text-red-700'
    : s.match(/Activo|Vigente|Disponible|Completado|Configurado/)
      ? 'bg-emerald-50 text-emerald-700'
      : 'bg-amber-50 text-amber-700';
export default function FleetApp() {
  const [session, setSession] = useState<{
    role: 'Administrador' | 'Solicitante';
    name: string;
  } | null>(null);
  const [active, setActive] = useState('Resumen'),
    [mobile, setMobile] = useState(false),
    [query, setQuery] = useState(''),
    [modal, setModal] = useState(false),
    [rows, setRows] = useState(modules);
  const current = modules[active];
  const filtered = useMemo(
    () =>
      current
        ? rows[active].rows.filter((r) =>
            Object.values(r)
              .join(' ')
              .toLowerCase()
              .includes(query.toLowerCase()),
          )
        : [],
    [active, query, rows, current],
  );
  function addRecord(e: React.SyntheticEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget),
      rawTitle = f.get('title'),
      rawSubtitle = f.get('subtitle'),
      title = typeof rawTitle === 'string' ? rawTitle : '',
      subtitle = typeof rawSubtitle === 'string' ? rawSubtitle : '';
    setRows((prev) => ({
      ...prev,
      [active]: {
        ...prev[active],
        rows: [
          {
            id: `${active.slice(0, 3).toUpperCase()}-${Date.now().toString().slice(-4)}`,
            title,
            subtitle,
            meta: 'Registrado ahora',
            status: 'Activo',
          },
          ...prev[active].rows,
        ],
      },
    }));
    setModal(false);
  }
  if (!session) return <CorporateAccess onAccess={setSession} />;
  if (session.role === 'Solicitante')
    return (
      <RequesterPortal name={session.name} onExit={() => setSession(null)} />
    );
  return (
    <div className="min-h-screen bg-[#f3f4f1] text-[#17201c]">
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-[#14221c] text-white transition-transform lg:translate-x-0 ${mobile ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-4">
          <button
            onClick={() => setActive('Resumen')}
            className="rounded-lg bg-white p-2"
          >
            <img
              src="/logo-montara.png"
              alt="MONTARA S.A.C."
              className="h-12 w-40 object-contain"
            />
          </button>
          <button className="lg:hidden" onClick={() => setMobile(false)}>
            <X size={20} />
          </button>
        </div>
        <p className="px-6 pt-3 text-[11px] text-white/40">
          Flota que mueve industrias.
        </p>
        <nav className="mt-3 flex-1 space-y-0.5 overflow-y-auto px-3">
          {nav.map(([label, Icon]) => (
            <button
              key={label}
              onClick={() => {
                setActive(label);
                setMobile(false);
                setQuery('');
              }}
              className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm ${active === label ? 'bg-[#e6b94c] font-semibold text-[#14221c]' : 'text-white/60 hover:bg-white/5 hover:text-white'}`}
            >
              <Icon size={16} />
              {label}
            </button>
          ))}
        </nav>
        <div className="m-3 rounded-lg border border-white/10 p-3 text-sm">
          <b>{session.name}</b>
          <div className="mt-1 flex items-center justify-between">
            <p className="text-xs text-white/40">Administrador</p>
            <button
              onClick={() => setSession(null)}
              aria-label="Cerrar sesión"
              className="text-white/45 hover:text-white"
            >
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>
      <main className="lg:pl-64">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-black/6 bg-[#f3f4f1]/90 px-4 backdrop-blur md:px-7">
          <button className="lg:hidden" onClick={() => setMobile(true)}>
            <Menu size={21} />
          </button>
          <div className="relative max-w-xl flex-1">
            <Search
              size={16}
              className="absolute left-3 top-2.5 text-black/35"
            />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar unidad, cliente o contrato..."
              className="h-9 w-full rounded-lg border border-black/8 bg-white pl-9 pr-3 text-sm outline-none"
            />
          </div>
          <button
            onClick={() => setActive('Alertas')}
            className="relative rounded-lg border border-black/8 bg-white p-2"
          >
            <Bell size={18} />
            <span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-white" />
          </button>
        </header>
        <div className="mx-auto max-w-[1450px] p-4 md:p-7">
          {active === 'Resumen' ? (
            <Dashboard go={setActive} />
          ) : (
            <>
              <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[.16em] text-[#987226]">
                    MONTARA Fleet
                  </p>
                  <h1 className="text-3xl font-black">{rows[active].title}</h1>
                  <p className="text-sm text-black/45">
                    {rows[active].description}
                  </p>
                </div>
                {!['Reportes', 'Alertas'].includes(active) && (
                  <button
                    onClick={() => setModal(true)}
                    className="flex items-center gap-2 rounded-lg bg-[#14221c] px-4 py-2.5 text-sm font-semibold text-white"
                  >
                    <Plus size={16} />
                    Nuevo registro
                  </button>
                )}
              </div>
              {active === 'Contratos' && <ContractWorkspace />}
              <div className="overflow-hidden rounded-xl border border-black/7 bg-white">
                <div className="flex items-center justify-between border-b border-black/6 p-4">
                  <b>{filtered.length} registros</b>
                  <span className="text-xs text-black/40">
                    Datos de demostración
                  </span>
                </div>
                {filtered.length ? (
                  <div className="divide-y divide-black/6">
                    {filtered.map((r) => (
                      <button
                        key={r.id}
                        className="grid w-full grid-cols-[1fr_auto] items-center gap-4 p-4 text-left hover:bg-black/[.02] md:grid-cols-[100px_1.2fr_1fr_140px_auto]"
                      >
                        <span className="text-xs font-bold text-black/40">
                          {r.id}
                        </span>
                        <div>
                          <b className="text-sm">{r.title}</b>
                          <p className="text-xs text-black/45">{r.subtitle}</p>
                        </div>
                        <p className="hidden text-sm text-black/50 md:block">
                          {r.meta}
                        </p>
                        <span
                          className={`w-fit rounded-full px-2.5 py-1 text-xs font-semibold ${pill(r.status)}`}
                        >
                          {r.status}
                        </span>
                        <span className="flex items-center gap-2 text-sm font-semibold">
                          {r.amount || ''}
                          <ChevronRight size={16} />
                        </span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-12 text-center text-sm text-black/40">
                    No hay resultados para “{query}”.
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </main>
      {modal && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/45 p-4"
          onMouseDown={() => setModal(false)}
        >
          <form
            onSubmit={addRecord}
            onMouseDown={(e) => e.stopPropagation()}
            className="w-full max-w-lg rounded-xl bg-white p-6 shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-[#987226]">
                  Nuevo registro
                </p>
                <h2 className="text-xl font-black">{active}</h2>
              </div>
              <button type="button" onClick={() => setModal(false)}>
                <X />
              </button>
            </div>
            <label className="mt-5 block text-sm font-semibold">
              Nombre o descripción
              <input
                name="title"
                required
                className="mt-1 h-10 w-full rounded-lg border border-black/10 px-3"
              />
            </label>
            <label className="mt-4 block text-sm font-semibold">
              Detalle
              <input
                name="subtitle"
                required
                className="mt-1 h-10 w-full rounded-lg border border-black/10 px-3"
              />
            </label>
            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setModal(false)}
                className="rounded-lg border px-4 py-2 text-sm"
              >
                Cancelar
              </button>
              <button className="rounded-lg bg-[#14221c] px-4 py-2 text-sm font-semibold text-white">
                Guardar registro
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
function ContractWorkspace() {
  const [signedFile, setSignedFile] = useState<string>('');
  return (
    <section className="mb-5 grid gap-4 rounded-xl border border-[#d9c690] bg-[#fffcf4] p-5 lg:grid-cols-[1fr_auto] lg:items-center">
      <div>
        <p className="text-xs font-bold uppercase tracking-[.16em] text-[#987226]">
          Flujo contractual
        </p>
        <h2 className="mt-1 text-lg font-black">Descarga, firma y registra</h2>
        <p className="mt-1 max-w-2xl text-sm text-black/50">
          Completa el modelo en Word, solicita revisión legal, hazlo firmar y
          selecciona aquí el PDF o DOCX final.
        </p>
        {signedFile && (
          <p className="mt-3 text-sm font-semibold text-emerald-700">
            Archivo seleccionado: {signedFile}
          </p>
        )}
      </div>
      <div className="flex flex-wrap gap-2">
        <a
          href="/docs/Modelo-Contrato-Alquiler-MONTARA.docx"
          download
          className="flex items-center gap-2 rounded-lg bg-[#14221c] px-4 py-2.5 text-sm font-semibold text-white"
        >
          <Download size={16} />
          Descargar modelo
        </a>
        <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-black/10 bg-white px-4 py-2.5 text-sm font-semibold">
          <UploadCloud size={16} />
          Subir contrato firmado
          <input
            type="file"
            accept=".pdf,.doc,.docx"
            className="sr-only"
            onChange={(event) =>
              setSignedFile(event.target.files?.[0]?.name ?? '')
            }
          />
        </label>
      </div>
    </section>
  );
}

function Dashboard({ go }: { go: (v: string) => void }) {
  return (
    <>
      <div className="mb-6">
        <p className="text-[11px] font-bold uppercase tracking-[.16em] text-[#987226]">
          Centro de operaciones
        </p>
        <h1 className="text-3xl font-black">Resumen ejecutivo</h1>
        <p className="text-sm text-black/45">
          31 de agosto de 2026 · Información consolidada
        </p>
      </div>
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ['Total de unidades', '24', '11 disponibles'],
          ['Unidades alquiladas', '10', '41.7% ocupación'],
          ['Ingresos del mes', 'S/ 18,400', '+12.4% vs. julio'],
          ['Utilidad estimada', 'S/ 11,650', '63.3% de margen'],
        ].map(([a, b, c]) => (
          <div
            key={a}
            className="rounded-xl border border-black/6 bg-white p-5"
          >
            <p className="text-sm text-black/45">{a}</p>
            <b className="mt-3 block text-3xl">{b}</b>
            <span className="text-xs text-[#987226]">{c}</span>
          </div>
        ))}
      </section>
      <div className="mt-4 grid gap-4 xl:grid-cols-[1.6fr_1fr]">
        <section className="rounded-xl border border-black/6 bg-white p-5">
          <div className="flex justify-between">
            <div>
              <b>Ingresos mensuales</b>
              <p className="text-xs text-black/40">Últimos seis meses</p>
            </div>
            <button
              onClick={() => go('Reportes')}
              className="text-xs font-bold text-[#987226]"
            >
              Ver reporte
            </button>
          </div>
          <div className="mt-3 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trend}>
                <CartesianGrid stroke="#e8e9e4" vertical={false} />
                <XAxis dataKey="m" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip />
                <Area
                  dataKey="v"
                  stroke="#b38c26"
                  strokeWidth={3}
                  fill="#e6b94c33"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>
        <section className="rounded-xl border border-black/6 bg-white p-5">
          <div className="flex justify-between">
            <div>
              <b>Alertas importantes</b>
              <p className="text-xs text-black/40">7 requieren atención</p>
            </div>
            <AlertTriangle size={18} className="text-[#b38c26]" />
          </div>
          <div className="mt-4 space-y-3">
            {[
              'SOAT MNT-001 · 8 días',
              'Contrato CTR-2026-012 · 12 días',
              'Pago F001-0082 · vencido',
              'Mantenimiento MNT-003 · en proceso',
            ].map((x, i) => (
              <div
                className="flex items-center gap-3 border-b border-black/6 pb-3 text-sm"
                key={x}
              >
                <span
                  className={`h-2 w-2 rounded-full ${i === 0 || i === 2 ? 'bg-red-500' : 'bg-amber-400'}`}
                />
                {x}
              </div>
            ))}
          </div>
          <button
            onClick={() => go('Alertas')}
            className="mt-3 w-full rounded-lg border py-2 text-xs font-semibold"
          >
            Ver todas
          </button>
        </section>
      </div>
    </>
  );
}

// oxlint-disable-next-line no-unused-vars
function LegacyAccessScreen({
  onAccess,
}: {
  onAccess: (session: {
    role: 'Administrador' | 'Solicitante';
    name: string;
  }) => void;
}) {
  return (
    <main className="min-h-screen bg-[#14221c] p-5 text-[#17201c]">
      <div className="mx-auto grid min-h-[calc(100vh-40px)] max-w-6xl overflow-hidden rounded-2xl bg-white shadow-2xl lg:grid-cols-[1.05fr_.95fr]">
        <section className="relative hidden overflow-hidden bg-[#17251f] p-12 text-white lg:flex lg:flex-col lg:justify-between">
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage:
                'linear-gradient(135deg,transparent 45%,#e7aa00 45%,#e7aa00 46%,transparent 46%)',
              backgroundSize: '90px 90px',
            }}
          />
          <img
            src="/logo-montara.png"
            alt="MONTARA S.A.C."
            className="relative w-72 rounded-xl bg-white p-4"
          />
          <div className="relative">
            <p className="mb-3 text-xs font-bold uppercase tracking-[.22em] text-[#e6b94c]">
              Gestión y alquiler de flota
            </p>
            <h1 className="max-w-lg text-5xl font-black leading-tight">
              Flota que mueve industrias.
            </h1>
            <p className="mt-5 max-w-md text-sm leading-6 text-white/55">
              Administra operaciones o solicita vehículos y equipos para tu
              próximo proyecto.
            </p>
          </div>
          <p className="relative text-xs text-white/30">
            © 2026 MONTARA S.A.C.
          </p>
        </section>
        <section className="flex items-center p-6 sm:p-10 lg:p-14">
          <div className="w-full">
            <img
              src="/logo-montara.png"
              alt="MONTARA S.A.C."
              className="mx-auto mb-8 w-56 lg:hidden"
            />
            <p className="text-xs font-bold uppercase tracking-[.18em] text-[#ac7f16]">
              Portal MONTARA
            </p>
            <h2 className="mt-2 text-3xl font-black">¿Cómo deseas ingresar?</h2>
            <p className="mt-2 text-sm text-black/45">
              Selecciona el tipo de acceso correspondiente.
            </p>
            <div className="mt-7 space-y-3">
              <div className="rounded-xl border border-black/8 p-4">
                <div className="mb-3 flex items-center gap-3">
                  <span className="rounded-lg bg-[#14221c] p-2 text-white">
                    <ShieldCheck size={19} />
                  </span>
                  <div>
                    <b>Administradores</b>
                    <p className="text-xs text-black/45">
                      Acceso completo al sistema
                    </p>
                  </div>
                </div>
                <button
                  onClick={() =>
                    onAccess({
                      role: 'Administrador',
                      name: 'Alyson Noely Diaz Mamani',
                    })
                  }
                  className="flex w-full items-center justify-between rounded-lg bg-[#f3f4f1] px-4 py-3 text-left text-sm font-semibold hover:bg-[#eee7d5]"
                >
                  Alyson Noely Diaz Mamani <ChevronRight size={17} />
                </button>
                <button
                  onClick={() =>
                    onAccess({
                      role: 'Administrador',
                      name: 'Maiquel Visa Diaz',
                    })
                  }
                  className="mt-2 flex w-full items-center justify-between rounded-lg bg-[#f3f4f1] px-4 py-3 text-left text-sm font-semibold hover:bg-[#eee7d5]"
                >
                  Maiquel Visa Diaz <ChevronRight size={17} />
                </button>
              </div>
              <button
                onClick={() =>
                  onAccess({ role: 'Solicitante', name: 'Visitante' })
                }
                className="flex w-full items-center justify-between rounded-xl border border-black/8 p-4 text-left hover:border-[#d3a12d]"
              >
                <span className="flex items-center gap-3">
                  <span className="rounded-lg bg-[#f0eadb] p-2 text-[#987226]">
                    <Users size={19} />
                  </span>
                  <span>
                    <b className="block">Solicitar nuestros servicios</b>
                    <span className="text-xs text-black/45">
                      Cotiza una unidad para tu empresa o proyecto
                    </span>
                  </span>
                </span>
                <ChevronRight size={18} />
              </button>
            </div>
            <p className="mt-6 text-center text-[11px] text-black/35">
              Vista de demostración. Las credenciales seguras se configurarán
              antes de producción.
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}

function RequesterPortal({
  name,
  onExit,
}: {
  name: string;
  onExit: () => void;
}) {
  const [sent, setSent] = useState(false);
  function submit(e: React.SyntheticEvent<HTMLFormElement>) {
    e.preventDefault();
    setSent(true);
  }
  return (
    <main className="min-h-screen bg-[#f3f4f1]">
      <header className="border-b border-black/7 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <img
            src="/logo-montara.png"
            alt="MONTARA S.A.C."
            className="h-14 w-44 object-contain"
          />
          <button
            onClick={onExit}
            className="flex items-center gap-2 text-sm font-semibold text-black/55"
          >
            <LogOut size={16} />
            Salir
          </button>
        </div>
      </header>
      <div className="mx-auto grid max-w-6xl gap-7 p-5 py-10 lg:grid-cols-[.8fr_1.2fr]">
        <section>
          <p className="text-xs font-bold uppercase tracking-[.18em] text-[#987226]">
            Portal del solicitante
          </p>
          <h1 className="mt-2 text-4xl font-black">
            Solicita la flota que tu operación necesita.
          </h1>
          <p className="mt-4 text-sm leading-6 text-black/50">
            Cuéntanos qué vehículo o equipo requieres. Nuestro equipo revisará
            la disponibilidad y se comunicará contigo para preparar una
            propuesta.
          </p>
          <div className="mt-7 rounded-xl bg-[#14221c] p-5 text-white">
            <p className="text-xs text-white/45">Perfil actual</p>
            <b>{name}</b>
            <p className="mt-4 text-xs text-[#e6b94c]">
              Solicitante de servicios
            </p>
          </div>
        </section>
        <section className="rounded-2xl border border-black/7 bg-white p-6 shadow-sm sm:p-8">
          {sent ? (
            <div className="grid min-h-96 place-items-center text-center">
              <div>
                <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-emerald-50 text-emerald-700">
                  <Send size={24} />
                </span>
                <h2 className="mt-4 text-2xl font-black">
                  Solicitud registrada
                </h2>
                <p className="mt-2 max-w-sm text-sm text-black/45">
                  El equipo administrador podrá revisarla en el módulo
                  Solicitudes.
                </p>
                <button
                  onClick={() => setSent(false)}
                  className="mt-5 rounded-lg bg-[#14221c] px-4 py-2 text-sm font-semibold text-white"
                >
                  Crear otra solicitud
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={submit}>
              <h2 className="text-xl font-black">
                Nueva solicitud de servicio
              </h2>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <label className="text-sm font-semibold">
                  Empresa
                  <input
                    required
                    className="mt-1 h-10 w-full rounded-lg border border-black/10 px-3"
                    placeholder="Razón social"
                  />
                </label>
                <label className="text-sm font-semibold">
                  Contacto
                  <input
                    required
                    className="mt-1 h-10 w-full rounded-lg border border-black/10 px-3"
                    placeholder="Nombre y apellido"
                  />
                </label>
                <label className="text-sm font-semibold">
                  Correo
                  <input
                    required
                    type="email"
                    className="mt-1 h-10 w-full rounded-lg border border-black/10 px-3"
                    placeholder="contacto@empresa.com"
                  />
                </label>
                <label className="text-sm font-semibold">
                  Teléfono
                  <input
                    required
                    className="mt-1 h-10 w-full rounded-lg border border-black/10 px-3"
                    placeholder="+51 999 999 999"
                  />
                </label>
                <label className="text-sm font-semibold">
                  Tipo de unidad
                  <select className="mt-1 h-10 w-full rounded-lg border border-black/10 bg-white px-3">
                    <option>Camioneta 4x4</option>
                    <option>Camión</option>
                    <option>Tráiler</option>
                    <option>Volquete</option>
                    <option>Minibús</option>
                    <option>Maquinaria</option>
                    <option>Otro equipo</option>
                  </select>
                </label>
                <label className="text-sm font-semibold">
                  Periodo estimado
                  <input
                    required
                    className="mt-1 h-10 w-full rounded-lg border border-black/10 px-3"
                    placeholder="Ej. 3 meses"
                  />
                </label>
              </div>
              <label className="mt-4 block text-sm font-semibold">
                Proyecto y requerimientos
                <textarea
                  required
                  rows={4}
                  className="mt-1 w-full rounded-lg border border-black/10 p-3"
                  placeholder="Ubicación, fecha de inicio y condiciones de operación..."
                />
              </label>
              <button className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg bg-[#e3aa19] px-5 py-3 text-sm font-bold text-[#14221c]">
                <Send size={17} />
                Enviar solicitud
              </button>
            </form>
          )}
        </section>
      </div>
    </main>
  );
}
