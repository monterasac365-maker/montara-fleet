# MONTARA Fleet

Sistema web responsive para administrar la flota de **MONTARA S.A.C.**  
_Flota que mueve industria._

## Requisitos

- Node.js 22.13 o superior
- npm
- Una base Cloudflare D1 (el entorno local usa Miniflare)

## Inicio local

```bash
npm install
npm run db:generate
npm run dev
```

Abra `http://localhost:3000`. La aplicación incluye datos ficticios para explorar todos los módulos.

## Comandos

```bash
npm run dev          # servidor local
npm run db:generate  # genera migraciones desde db/schema.ts
npm run lint         # análisis estático
npm run build        # build de producción
npm run start        # ejecuta el build con Wrangler
```

## Arquitectura

- `app/`: rutas y metadata
- `components/fleet-app.tsx`: superficie operativa responsive
- `components/ui/`: primitivas accesibles reutilizables
- `db/schema.ts`: modelo relacional Drizzle
- `drizzle/`: migraciones SQL versionadas
- `.openai/hosting.json`: bindings de infraestructura

Los importes se almacenan como enteros en céntimos para evitar errores de punto flotante. El modelo cubre usuarios/roles, categorías, propietarios, clientes, activos, alquileres, contratos, pagos, gastos, mantenimiento, documentos, alertas y configuración.

## Configuración

No se requieren secretos en el frontend. El binding lógico de base de datos es `DB`. En producción, el hosting inyecta el recurso D1 real. La moneda inicial es PEN y el IGV vive en configuración, no en las reglas del dominio.

## Estado funcional

La interfaz incluye dashboard, búsqueda global, navegación responsive, listados de todos los módulos, estados, alertas, datos ficticios y creación de registros durante la sesión. La migración SQL completa queda lista para persistencia.

Quedan para la siguiente fase: enlazar todos los formularios a endpoints D1, edición/eliminación persistente, carga de archivos en R2, autenticación y autorización de producción, exportaciones Excel/PDF, SUNAT, notificaciones y portales externos. No se muestran controles falsos para esas integraciones.

## Despliegue

El proyecto usa Vinext y Cloudflare Workers. Ejecute `npm run build` y publique con Sites para que el servicio asigne la base D1 y las políticas de acceso. Configure el sitio como privado hasta completar la matriz de autorización por roles.
