from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "deliverables"
WEB = ROOT / "public" / "docs"
LOGO = ROOT / "public" / "logo-montara.png"
OUT.mkdir(exist_ok=True)
WEB.mkdir(parents=True, exist_ok=True)

GREEN = "14221C"
GOLD = "E6B94C"
INK = "17201C"
MUTED = "66716B"
LIGHT = "F2F4F1"

def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)

def margins(cell, top=100, start=120, bottom=100, end=120):
    tc = cell._tc.get_or_add_tcPr()
    tcMar = tc.first_child_found_in("w:tcMar")
    if tcMar is None:
        tcMar = OxmlElement("w:tcMar")
        tc.append(tcMar)
    for side, value in (("top",top),("start",start),("bottom",bottom),("end",end)):
        node = OxmlElement(f"w:{side}")
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")
        tcMar.append(node)

def set_cell_width(cell, twips):
    tcPr = cell._tc.get_or_add_tcPr()
    tcW = tcPr.first_child_found_in("w:tcW")
    if tcW is None:
        tcW = OxmlElement("w:tcW")
        tcPr.append(tcW)
    tcW.set(qn("w:w"), str(twips))
    tcW.set(qn("w:type"), "dxa")

def configure(doc, title):
    sec = doc.sections[0]
    sec.top_margin = Inches(.78)
    sec.bottom_margin = Inches(.72)
    sec.left_margin = Inches(.82)
    sec.right_margin = Inches(.82)
    sec.header_distance = Inches(.3)
    sec.footer_distance = Inches(.35)
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Arial"
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = RGBColor.from_string(INK)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.18
    for name, size, color, before, after in [
        ("Title", 27, GREEN, 0, 8), ("Subtitle", 12, MUTED, 0, 14),
        ("Heading 1", 17, GREEN, 15, 7), ("Heading 2", 13, GREEN, 11, 5),
        ("Heading 3", 11, MUTED, 8, 4)
    ]:
        s = styles[name]
        s.font.name = "Arial"
        s.font.size = Pt(size)
        s.font.color.rgb = RGBColor.from_string(color)
        s.font.bold = name != "Subtitle"
        s.paragraph_format.space_before = Pt(before)
        s.paragraph_format.space_after = Pt(after)
        s.paragraph_format.keep_with_next = True
    header = sec.header
    p = header.paragraphs[0]
    p.text = f"MONTARA S.A.C.  |  {title}"
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for r in p.runs:
        r.font.name = "Arial"; r.font.size = Pt(8); r.font.color.rgb = RGBColor.from_string(MUTED)
    footer = sec.footer
    p = footer.paragraphs[0]
    p.text = "Flota que mueve industrias.  |  Documento editable"
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in p.runs:
        r.font.name = "Arial"; r.font.size = Pt(8); r.font.color.rgb = RGBColor.from_string(MUTED)

def cover(doc, kicker, title, subtitle, version):
    if LOGO.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(LOGO), width=Inches(2.65))
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(18)
    r = p.add_run(kicker.upper())
    r.bold = True; r.font.name = "Arial"; r.font.size = Pt(9); r.font.color.rgb = RGBColor.from_string(GOLD)
    p = doc.add_paragraph(title, "Title")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = doc.add_paragraph(subtitle, "Subtitle")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = doc.add_paragraph(version)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in p.runs:
        r.font.size = Pt(9); r.font.color.rgb = RGBColor.from_string(MUTED)

def callout(doc, label, text):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.cell(0,0)
    set_cell_width(cell, 9360); margins(cell, 150, 180, 150, 180); shade(cell, LIGHT)
    p = cell.paragraphs[0]
    r = p.add_run(label + "  "); r.bold = True; r.font.color.rgb = RGBColor.from_string(GREEN)
    p.add_run(text)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)

def add_bullets(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        p.add_run(item)

def add_steps(doc, items):
    style = doc.styles["List Number"]
    base_num_id = style._element.pPr.numPr.numId.val
    numbering = doc.part.numbering_part.element
    base_num = numbering.num_having_numId(base_num_id)
    abstract_id = base_num.abstractNumId.val
    new_num = numbering.add_num(abstract_id)
    new_num.add_lvlOverride(ilvl=0).add_startOverride(1)
    for item in items:
        p = doc.add_paragraph(style="List Number")
        num_pr = p._p.get_or_add_pPr().get_or_add_numPr()
        num_pr.get_or_add_ilvl().val = 0
        num_pr.get_or_add_numId().val = new_num.numId
        p.add_run(item)

def field_table(doc, rows):
    table = doc.add_table(rows=0, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for label, value in rows:
        cells = table.add_row().cells
        set_cell_width(cells[0], 2700); set_cell_width(cells[1], 6660)
        for c in cells: margins(c); c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        shade(cells[0], LIGHT)
        r = cells[0].paragraphs[0].add_run(label); r.bold = True; r.font.color.rgb = RGBColor.from_string(GREEN)
        cells[1].paragraphs[0].add_run(value)
    table.style = "Table Grid"
    return table

def build_manual():
    doc = Document(); configure(doc, "Manual de administración")
    cover(doc, "Guía operativa", "Manual de administración y personalización", "MONTARA Fleet", "Versión 1.0 | Agosto 2026")
    callout(doc, "Propósito", "Explicar cómo usar, respaldar y modificar el sistema sin perder información.")
    doc.add_page_break()
    doc.add_heading("1. Accesos y perfiles", 1)
    doc.add_paragraph("MONTARA Fleet utiliza dos experiencias separadas:")
    add_bullets(doc, [
        "Administrador: acceso al panel completo de flota, clientes, solicitudes, contratos, finanzas, mantenimiento y configuración.",
        "Solicitante: registro sin contraseña para enviar requerimientos comerciales y consultar el flujo de su solicitud."
    ])
    field_table(doc, [("Administrador 1","Alyson Noely Diaz Mamani"),("Administrador 2","Maiquel Visa Diaz"),("Usuarios iniciales","alyson / maiquel"),("Contraseñas","Deben configurarse en el servidor. Nunca deben escribirse dentro del código.")])
    doc.add_heading("2. Recorrido del panel", 1)
    for title, desc in [
        ("Resumen","Indicadores de disponibilidad, alquileres, ingresos, utilidad y alertas."),
        ("Flota","Registro de vehículos y equipos, estado, propietario, tarifa y ubicación."),
        ("Solicitudes","Requerimientos enviados desde la página pública."),
        ("Contratos","Descarga de plantilla, control de vigencia y carga del ejemplar firmado."),
        ("Finanzas","Pagos, facturación y gastos operativos."),
        ("Mantenimiento y documentos","Historial técnico, SOAT, seguros y vencimientos."),
        ("Configuración","Empresa, IGV, categorías y usuarios.")
    ]:
        doc.add_heading(title, 2); doc.add_paragraph(desc)
    doc.add_page_break()
    doc.add_heading("3. Cómo cambiar textos e identidad", 1)
    add_steps(doc, [
        "Abra la carpeta del proyecto y realice un respaldo antes de modificar.",
        "Edite la portada corporativa en components/corporate-access.tsx.",
        "Edite los módulos y datos de demostración en components/fleet-app.tsx.",
        "Reemplace public/logo-montara.png conservando el mismo nombre para cambiar el logo.",
        "Revise app/layout.tsx para cambiar el título y la descripción que aparecen al compartir la web.",
        "Ejecute npm run lint y npm run build antes de publicar."
    ])
    callout(doc, "Importante", "No publique contraseñas, claves API, tokens ni documentos firmados dentro de la carpeta public.")
    doc.add_heading("4. Cómo modificar la misión, visión y fundadores", 1)
    doc.add_paragraph("Busque los textos «Nuestra misión», «Nuestra visión» y «Fundadores» en components/corporate-access.tsx. Cambie únicamente el contenido entre las etiquetas de texto, manteniendo la estructura visual.")
    doc.add_heading("5. Contratos", 1)
    add_steps(doc, [
        "Ingrese como administrador y abra Contratos.",
        "Descargue el modelo editable en Word.",
        "Complete los campos entre corchetes y solicite revisión legal.",
        "Imprima o firme digitalmente el documento.",
        "Use «Subir contrato firmado» para seleccionar el PDF o DOCX final.",
        "Verifique cliente, unidad, fecha de vencimiento y estado."
    ])
    doc.add_page_break()
    doc.add_heading("6. Respaldo y recuperación", 1)
    add_steps(doc, [
        "Descargue y conserve el archivo MONTARA-Fleet-respaldo.zip en una ubicación segura.",
        "Mantenga una copia adicional fuera del equipo principal.",
        "Para recuperar, descomprima el respaldo, abra una terminal en la carpeta y ejecute npm install.",
        "Genere la base con npm run db:generate y arranque con npm run dev.",
        "Los archivos subidos y la base de producción deben exportarse por separado cuando R2/D1 estén activos."
    ])
    doc.add_heading("7. Publicación", 1)
    doc.add_paragraph("La versión de producción se publica con Sites. Antes de hacerla pública, confirme que el formulario administrativo valide contraseñas en el servidor y que la política de privacidad esté vigente.")
    doc.add_heading("8. Verificación antes de cada cambio", 1)
    add_bullets(doc, ["El logo carga correctamente.","La portada funciona en celular y computadora.","Los enlaces de navegación responden.","La plantilla contractual se descarga.","El formulario de carga acepta PDF o DOCX.","npm run lint finaliza sin errores.","npm run build finaliza sin errores."])
    path = OUT / "Manual-MONTARA-Fleet.docx"; doc.save(path)
    (WEB / path.name).write_bytes(path.read_bytes())
    return path

def clause(doc, number, title, text):
    doc.add_heading(f"{number}. {title}", 2)
    doc.add_paragraph(text)

def build_contract():
    doc = Document(); configure(doc, "Modelo de contrato")
    cover(doc, "Modelo editable", "Contrato de alquiler de unidad o equipo", "MONTARA S.A.C.", "Plantilla referencial | Requiere revisión legal antes de su uso")
    callout(doc, "Aviso legal", "Esta plantilla es un punto de partida operativo. Debe ser revisada y adaptada por un abogado peruano antes de firmarse.")
    doc.add_page_break()
    doc.add_heading("CONTRATO N.° [000-2026-MONTARA]", 1)
    doc.add_paragraph("Conste por el presente documento el contrato de alquiler que celebran:")
    field_table(doc, [
        ("EL ARRENDADOR","MONTARA S.A.C., RUC [___________], domicilio en [___________], representada por [___________], DNI [___________]."),
        ("EL CLIENTE","[RAZÓN SOCIAL], RUC [___________], domicilio en [___________], representada por [___________], DNI [___________]."),
        ("PROYECTO","[Nombre y ubicación del proyecto / unidad minera].")
    ])
    clause(doc,"1","Objeto","EL ARRENDADOR entrega en alquiler a EL CLIENTE la unidad o equipo descrito en el Anexo 1, para uso exclusivo en el proyecto indicado y conforme a las condiciones de este contrato.")
    clause(doc,"2","Plazo","El alquiler inicia el [dd/mm/aaaa] y finaliza el [dd/mm/aaaa]. Cualquier prórroga deberá constar por escrito.")
    clause(doc,"3","Tarifa y forma de pago","La tarifa es de S/ [________] más IGV por [día/semana/mes]. El pago vencerá el [día] de cada periodo. La garantía asciende a S/ [________].")
    clause(doc,"4","Entrega y devolución","La unidad se entrega con el kilometraje/horómetro, combustible, accesorios y estado consignados en el acta. EL CLIENTE la devolverá en condiciones equivalentes, salvo desgaste normal.")
    clause(doc,"5","Uso autorizado","EL CLIENTE utilizará la unidad únicamente para actividades lícitas, con personal autorizado y licencias vigentes. No podrá subarrendar, ceder ni trasladar la unidad fuera del área acordada sin autorización escrita.")
    clause(doc,"6","Mantenimiento","EL ARRENDADOR coordinará el mantenimiento preventivo. EL CLIENTE informará inmediatamente cualquier falla y facilitará el acceso. Los daños derivados de uso indebido serán asumidos por la parte responsable.")
    clause(doc,"7","Seguros, SOAT y documentos","Las partes verificarán la vigencia de SOAT, seguros, revisión técnica y documentos aplicables. Las exclusiones, deducibles y responsabilidades se detallarán en el Anexo 2.")
    clause(doc,"8","Siniestros y emergencias","EL CLIENTE notificará accidentes, robos o daños de inmediato, realizará la denuncia correspondiente y no reconocerá responsabilidad ante terceros sin coordinación con EL ARRENDADOR y la aseguradora.")
    clause(doc,"9","Penalidades y resolución","El incumplimiento de pago, uso no autorizado o afectación grave de la unidad facultará a la parte cumplida a resolver el contrato, previa comunicación, sin perjuicio de las obligaciones pendientes.")
    clause(doc,"10","Protección de datos y confidencialidad","Las partes tratarán los datos y documentos recibidos únicamente para ejecutar la relación contractual y cumplir obligaciones legales.")
    clause(doc,"11","Ley aplicable y controversias","El contrato se rige por las leyes de la República del Perú. Las partes buscarán una solución directa y, de no alcanzarla, se someterán a [arbitraje/jurisdicción] en [ciudad].")
    clause(doc,"12","Domicilios y comunicaciones","Las comunicaciones serán válidas en los domicilios y correos indicados por las partes. Todo cambio deberá informarse por escrito.")
    doc.add_page_break()
    doc.add_heading("Anexo 1. Identificación de la unidad", 1)
    field_table(doc,[("Código interno","[___________]"),("Placa / serie","[___________]"),("Categoría","[___________]"),("Marca y modelo","[___________]"),("Año / color","[___________]"),("VIN","[___________]"),("Kilometraje inicial","[___________] km"),("Horómetro inicial","[___________] h"),("Tarifa","S/ [___________] por [___________]"),("Ubicación de operación","[___________]")])
    doc.add_heading("Anexo 2. Acta de entrega y checklist", 1)
    checks=["Tarjeta de propiedad","SOAT vigente","Seguro vigente","Revisión técnica","Llaves y duplicado","Llanta de repuesto","Herramientas y gata","Extintor y botiquín","GPS","Fotografías de entrega"]
    table=doc.add_table(rows=1,cols=3); table.style="Table Grid"; table.alignment=WD_TABLE_ALIGNMENT.CENTER
    hdr=table.rows[0].cells
    for i,t in enumerate(["Elemento","Conforme","Observaciones"]): hdr[i].text=t; shade(hdr[i],GREEN); hdr[i].paragraphs[0].runs[0].font.color.rgb=RGBColor(255,255,255); hdr[i].paragraphs[0].runs[0].bold=True
    for item in checks:
        c=table.add_row().cells; c[0].text=item; c[1].text="☐ Sí   ☐ No"; c[2].text=""
        set_cell_width(c[0],3600); set_cell_width(c[1],2100); set_cell_width(c[2],3660)
        for x in c: margins(x)
    doc.add_heading("Firmas", 1)
    doc.add_paragraph("Firmado en [ciudad], el [día] de [mes] de [año], en dos ejemplares.")
    sig=doc.add_table(rows=1,cols=2); sig.alignment=WD_TABLE_ALIGNMENT.CENTER
    sig.cell(0,0).text="\n\n\n______________________________\nMONTARA S.A.C.\nNombre: [___________]\nDNI: [___________]"
    sig.cell(0,1).text="\n\n\n______________________________\nEL CLIENTE\nNombre: [___________]\nDNI: [___________]"
    for c in sig.rows[0].cells: set_cell_width(c,4680); margins(c,160,180,160,180)
    path=OUT/"Modelo-Contrato-Alquiler-MONTARA.docx"; doc.save(path)
    (WEB/path.name).write_bytes(path.read_bytes())
    return path

if __name__ == "__main__":
    print(build_manual())
    print(build_contract())
