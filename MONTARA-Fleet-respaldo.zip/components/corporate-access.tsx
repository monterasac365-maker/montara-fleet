'use client';
import { useState } from 'react';
import {
  ArrowRight,
  Building2,
  KeyRound,
  Mountain,
  ShieldCheck,
  Truck,
  Users,
  X,
} from 'lucide-react';

type Session = { role: 'Administrador' | 'Solicitante'; name: string };
const admins: Record<string, string> = {
  alyson: 'Alyson Noely Diaz Mamani',
  maiquel: 'Maiquel Visa Diaz',
};

export default function CorporateAccess({
  onAccess,
}: {
  onAccess: (session: Session) => void;
}) {
  const [modal, setModal] = useState<'admin' | 'requester' | null>(null),
    [error, setError] = useState('');
  function adminLogin(e: React.SyntheticEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const rawUsername = data.get('username');
    const rawPassword = data.get('password');
    const username =
      typeof rawUsername === 'string' ? rawUsername.trim().toLowerCase() : '';
    const password = typeof rawPassword === 'string' ? rawPassword : '';
    if (!admins[username]) {
      setError('Usuario administrador no reconocido.');
      return;
    }
    if (password.length < 8) {
      setError('La contraseña debe tener al menos 8 caracteres.');
      return;
    }
    onAccess({ role: 'Administrador', name: admins[username] });
  }
  function requesterRegister(e: React.SyntheticEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const rawName = data.get('name');
    const name = typeof rawName === 'string' ? rawName.trim() : '';
    if (name) onAccess({ role: 'Solicitante', name });
  }
  return (
    <main className="min-h-screen bg-[#fbfbf8] text-[#17201c]">
      <header className="sticky top-0 z-30 border-b border-black/7 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5">
          <img
            src="/logo-montara.png"
            alt="MONTARA S.A.C."
            className="h-16 w-48 object-contain"
          />
          <nav className="hidden items-center gap-7 text-sm font-semibold md:flex">
            <a href="#nosotros">Nosotros</a>
            <a href="#servicios">Servicios</a>
            <a href="#contacto">Contacto</a>
          </nav>
          <button
            onClick={() => setModal('admin')}
            className="flex items-center gap-2 rounded-lg bg-[#14221c] px-4 py-2.5 text-sm font-semibold text-white"
          >
            <KeyRound size={16} />
            Acceso administrativo
          </button>
        </div>
      </header>
      <section className="relative overflow-hidden bg-[#14221c] text-white">
        <div
          className="absolute inset-0 opacity-15"
          style={{
            backgroundImage:
              'linear-gradient(130deg,transparent 45%,#e6b94c 45%,#e6b94c 46%,transparent 46%)',
            backgroundSize: '110px 110px',
          }}
        />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-5 py-20 lg:grid-cols-[1.1fr_.9fr] lg:py-28">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.24em] text-[#e6b94c]">
              Alquiler de vehículos y equipos
            </p>
            <h1 className="mt-5 max-w-3xl text-5xl font-black leading-[1.05] sm:text-6xl">
              Flota que mueve industrias.
            </h1>
            <p className="mt-6 max-w-xl text-base leading-7 text-white/60">
              Soluciones de movilidad y equipos para minería, construcción,
              transporte y operaciones empresariales en el Perú.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button
                onClick={() => setModal('requester')}
                className="flex items-center gap-2 rounded-lg bg-[#e6b94c] px-5 py-3 font-bold text-[#14221c]"
              >
                Solicitar cotización <ArrowRight size={18} />
              </button>
              <a
                href="#nosotros"
                className="rounded-lg border border-white/20 px-5 py-3 font-semibold text-white"
              >
                Conocer MONTARA
              </a>
            </div>
          </div>
          <div className="hidden place-items-center lg:grid">
            <div className="rounded-2xl bg-white p-7 shadow-2xl">
              <img
                src="/logo-montara.png"
                alt="Logo MONTARA S.A.C."
                className="w-96"
              />
            </div>
          </div>
        </div>
      </section>
      <section id="nosotros" className="mx-auto max-w-7xl px-5 py-20">
        <div className="mb-12 max-w-2xl">
          <p className="text-xs font-bold uppercase tracking-[.2em] text-[#a77a13]">
            Quiénes somos
          </p>
          <h2 className="mt-3 text-4xl font-black">
            Un aliado para operaciones que no pueden detenerse.
          </h2>
        </div>
        <div className="grid gap-5 md:grid-cols-2">
          <article className="rounded-2xl border border-black/7 bg-white p-7">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#14221c] text-[#e6b94c]">
              <Mountain />
            </span>
            <h3 className="mt-5 text-2xl font-black">Nuestra misión</h3>
            <p className="mt-3 leading-7 text-black/55">
              Brindar soluciones confiables de alquiler de vehículos, maquinaria
              y equipos, asegurando disponibilidad, seguridad y atención
              eficiente para impulsar las operaciones de nuestros clientes.
            </p>
          </article>
          <article className="rounded-2xl border border-black/7 bg-white p-7">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#f0eadb] text-[#987226]">
              <Building2 />
            </span>
            <h3 className="mt-5 text-2xl font-black">Nuestra visión</h3>
            <p className="mt-3 leading-7 text-black/55">
              Ser una empresa peruana referente en gestión y alquiler de flota
              para industria y minería, reconocida por su servicio responsable,
              moderno y orientado a relaciones de largo plazo.
            </p>
          </article>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-5 pb-20">
        <div className="rounded-2xl bg-[#14221c] p-7 text-white sm:p-9">
          <p className="text-xs font-bold uppercase tracking-[.2em] text-[#e6b94c]">
            Fundadores
          </p>
          <div className="mt-5 grid gap-5 sm:grid-cols-2">
            <div>
              <b className="text-lg">José Flavio Visa Viza</b>
              <p className="mt-1 text-sm text-white/45">Fundador de MONTARA S.A.C.</p>
            </div>
            <div>
              <b className="text-lg">Armando Hidalgo Diaz Jara</b>
              <p className="mt-1 text-sm text-white/45">Fundador de MONTARA S.A.C.</p>
            </div>
          </div>
        </div>
      </section>
      <section id="servicios" className="bg-[#eef0eb]">
        <div className="mx-auto max-w-7xl px-5 py-20">
          <p className="text-xs font-bold uppercase tracking-[.2em] text-[#a77a13]">
            Nuestros servicios
          </p>
          <h2 className="mt-3 text-4xl font-black">
            Flota preparada para cada operación.
          </h2>
          <div className="mt-9 grid gap-4 md:grid-cols-3">
            {[
              [
                Truck,
                'Camionetas y transporte',
                'Unidades 4x4 y vehículos para personal, supervisión y logística.',
              ],
              [
                Mountain,
                'Maquinaria y equipos',
                'Equipos para proyectos mineros, industriales y de construcción.',
              ],
              [
                ShieldCheck,
                'Gestión confiable',
                'Mantenimiento, documentación y seguimiento operativo de cada unidad.',
              ],
            ].map(([Icon, title, text]) => (
              <article key={String(title)} className="rounded-xl bg-white p-6">
                <Icon className="text-[#b48418]" />
                <h3 className="mt-5 text-lg font-black">{String(title)}</h3>
                <p className="mt-2 text-sm leading-6 text-black/50">
                  {String(text)}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section id="contacto" className="mx-auto max-w-7xl px-5 py-20">
        <div className="flex flex-col items-start justify-between gap-7 rounded-2xl bg-[#14221c] p-8 text-white sm:p-12 md:flex-row md:items-center">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.2em] text-[#e6b94c]">
              Trabajemos juntos
            </p>
            <h2 className="mt-3 text-3xl font-black">
              ¿Qué unidad necesita tu proyecto?
            </h2>
            <p className="mt-2 text-sm text-white/55">
              Registra tus datos sin contraseña y envíanos tu requerimiento.
            </p>
          </div>
          <button
            onClick={() => setModal('requester')}
            className="whitespace-nowrap rounded-lg bg-[#e6b94c] px-5 py-3 font-bold text-[#14221c]"
          >
            Solicitar servicio
          </button>
        </div>
      </section>
      <footer className="border-t border-black/7 bg-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-6">
          <img
            src="/logo-montara.png"
            alt="MONTARA S.A.C."
            className="h-14 w-44 object-contain"
          />
          <p className="text-xs text-black/40">
            © 2026 MONTARA S.A.C. · Flota que mueve industrias.
          </p>
        </div>
      </footer>
      {modal && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-[#07120d]/70 p-4">
          <section className="relative w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl sm:p-8">
            <button
              onClick={() => {
                setModal(null);
                setError('');
              }}
              aria-label="Cerrar"
              className="absolute right-5 top-5 text-black/40"
            >
              <X />
            </button>
            {modal === 'admin' ? (
              <form onSubmit={adminLogin}>
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#14221c] text-[#e6b94c]">
                  <KeyRound />
                </span>
                <h2 className="mt-5 text-2xl font-black">
                  Acceso administrativo
                </h2>
                <p className="mt-1 text-sm text-black/45">
                  Ingresa con tu usuario y contraseña personal.
                </p>
                <label className="mt-6 block text-sm font-semibold">
                  Usuario
                  <input
                    name="username"
                    required
                    autoComplete="username"
                    className="mt-1 h-11 w-full rounded-lg border border-black/10 px-3"
                    placeholder="Usuario"
                  />
                </label>
                <label className="mt-4 block text-sm font-semibold">
                  Contraseña
                  <input
                    name="password"
                    required
                    minLength={8}
                    type="password"
                    autoComplete="current-password"
                    className="mt-1 h-11 w-full rounded-lg border border-black/10 px-3"
                    placeholder="••••••••"
                  />
                </label>
                {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
                <button className="mt-6 w-full rounded-lg bg-[#14221c] py-3 font-bold text-white">
                  Ingresar al panel
                </button>
                <p className="mt-4 text-center text-[11px] text-black/35">
                  Usuarios iniciales: alyson y maiquel. Las contraseñas no se
                  guardan en el código.
                </p>
              </form>
            ) : (
              <form onSubmit={requesterRegister}>
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#f0eadb] text-[#987226]">
                  <Users />
                </span>
                <h2 className="mt-5 text-2xl font-black">
                  Registro de solicitante
                </h2>
                <p className="mt-1 text-sm text-black/45">
                  No necesitas contraseña. Usaremos estos datos para atender tu
                  solicitud.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <label className="text-sm font-semibold">
                    Nombre completo
                    <input
                      name="name"
                      required
                      className="mt-1 h-11 w-full rounded-lg border border-black/10 px-3"
                    />
                  </label>
                  <label className="text-sm font-semibold">
                    Empresa
                    <input
                      name="company"
                      required
                      className="mt-1 h-11 w-full rounded-lg border border-black/10 px-3"
                    />
                  </label>
                  <label className="text-sm font-semibold">
                    Correo
                    <input
                      name="email"
                      required
                      type="email"
                      className="mt-1 h-11 w-full rounded-lg border border-black/10 px-3"
                    />
                  </label>
                  <label className="text-sm font-semibold">
                    Teléfono
                    <input
                      name="phone"
                      required
                      className="mt-1 h-11 w-full rounded-lg border border-black/10 px-3"
                    />
                  </label>
                </div>
                <label className="mt-4 flex items-start gap-2 text-xs text-black/50">
                  <input required type="checkbox" className="mt-0.5" />
                  Acepto que MONTARA use mis datos para responder esta
                  solicitud.
                </label>
                <button className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-[#e6b94c] py-3 font-bold text-[#14221c]">
                  Registrarme y solicitar <ArrowRight size={17} />
                </button>
              </form>
            )}
          </section>
        </div>
      )}
    </main>
  );
}
