import { roles, users } from "./schema";

export const initialRoles: Array<typeof roles.$inferInsert> = [
  { id: "role-admin", name: "Administrador", permissions: ["*"] },
  { id: "role-requester", name: "Solicitante", permissions: ["service_requests:create", "service_requests:read_own"] },
];

export const initialUsers: Array<typeof users.$inferInsert> = [
  { id: "admin-alyson", name: "Alyson Noely Diaz Mamani", roleId: "role-admin", active: true },
  { id: "admin-maiquel", name: "Maiquel Visa Diaz", roleId: "role-admin", active: true },
];
