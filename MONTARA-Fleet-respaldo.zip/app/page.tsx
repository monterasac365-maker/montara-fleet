import FleetApp from "@/components/fleet-app";
export default function Home(){return <FleetApp/>}
