import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'MONTARA Fleet',
  description: 'Gestión integral de flota para MONTARA S.A.C.',
  openGraph: {
    title: 'MONTARA Fleet',
    description: 'Flota que mueve industria.',
    images: [{ url: '/og.png', width: 1732, height: 909 }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MONTARA Fleet',
    description: 'Flota que mueve industria.',
    images: ['/og.png'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
